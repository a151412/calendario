from django import forms
from .models import Item
from .models import Atividade

class ItemForm(forms.ModelForm):
    class Meta:
        model = Item
        fields = ['nome', 'cor']

class AtividadeForm(forms.ModelForm):
    data_execucao = forms.DateField(
        widget=forms.DateInput(format='%Y-%m-%d'),
        input_formats=['%Y-%m-%d']
    )
    hora_execucao = forms.TimeField(
        widget=forms.TimeInput(format='%H:%M'),
        input_formats=['%H:%M']
    )

    class Meta:
        model = Atividade
        fields = ['data_execucao', 'hora_execucao', 'descricao', 'detalhes', 'area']


