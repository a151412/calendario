from django.urls import path
from . import views

urlpatterns = [
    path('', views.item_list, name='item_list'),
    path('new/', views.item_create, name='item_create'),
    path('edit/<int:pk>/', views.item_update, name='item_update'),
    path('delete/<int:pk>/', views.item_delete, name='item_delete'),
    path('atividades/', views.atividade_list, name='atividade_list'),
    path('atividades/new/', views.atividade_create, name='atividade_create'),
    path('atividades/edit/<int:pk>/', views.atividade_update, name='atividade_update'),
    path('atividades/delete/<int:pk>/', views.atividade_delete, name='atividade_delete'),
]
