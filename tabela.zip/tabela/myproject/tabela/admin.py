from django.contrib import admin
from .models import Atividade, Item

admin.site.register(Atividade)
admin.site.register(Item)
