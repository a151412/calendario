from django.db import models

class Item(models.Model):
    nome = models.CharField(max_length=100)
    cor = models.CharField(max_length=50)

    def __str__(self):
        return self.nome

class Atividade(models.Model):
    data_execucao = models.DateField()
    hora_execucao = models.TimeField()
    descricao = models.CharField(max_length=255)
    detalhes = models.TextField()
    area = models.ForeignKey(Item, on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.descricao} em {self.data_execucao} às {self.hora_execucao}"
